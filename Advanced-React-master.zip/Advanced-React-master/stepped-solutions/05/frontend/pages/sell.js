import Link from 'next/link';

const Sell = props => (
  <div>
    <p>Sell!</p>
  </div>
);

export default Sell;
