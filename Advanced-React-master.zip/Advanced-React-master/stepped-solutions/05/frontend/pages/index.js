import Link from 'next/link';

const Home = props => (
  <div>
    <p>Hey!</p>
  </div>
);

export default Home;
