import Home from './index';

export default Home;
