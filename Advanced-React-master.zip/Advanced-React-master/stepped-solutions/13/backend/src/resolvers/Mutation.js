const Mutations = {};

module.exports = Mutations;
