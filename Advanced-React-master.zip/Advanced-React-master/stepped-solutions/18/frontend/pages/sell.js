import CreateItem from '../components/CreateItem';

const Sell = props => (
  <div>
    <CreateItem />
  </div>
);

export default Sell;
